﻿using log4net;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Win.Data;

namespace WinDemo
{
    public partial class TimeTable : Form
    {
        dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        StringBuilder warning = new StringBuilder();
        /// <summary>
        /// 加载优化表
        /// </summary>
        public TimeTable()
        {
            InitializeComponent();
            ComClass com = new ComClass();
            com.DoubleBufferedGrid(grdView, true);
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.skinEngine1.SkinFile = Application.StartupPath + "//DiamondBlue.ssk";
        }
         /// <summary>
         /// 初始化表
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="e"></param>
        private void TimeTable_Load(object sender, EventArgs e)
        {
            Query();
            CboxDay.SelectedIndex = 0;
        }
        /// <summary>
        /// 查询整表函数
        /// </summary>
        private void Query()
        {
            StringBuilder str = new StringBuilder();
            str.Append("select z.classn_,t.conum_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.mon_) as mon_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.tue_) as tue_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.wed_) as wed_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.thur_) as thur_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.fri_) as fri_");
            str.Append(" from z_tmp_timetable t, z_Tmp_Classinfo z where t.class_ = z.id order by Class_, conum_");
            DataTable dtUser = dao.GetDataTable(str.ToString());
            grdView.DataSource = dtUser;
        }
        /// <summary> 
        /// 生成课表
        /// </summary>
        private void Generate()
        {
            string sql = "select count(*)from z_tmp_classinfo";
            int n = Convert.ToInt32(dao.ExecuteScale(sql).ToString());
            for(int i = 1; i < n + 1; i++)
            {   
                GenerateTiemTable(i);
            }
        }
        /// <summary>
        /// 生成按钮动作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            string delet = "delete from  z_tmp_timetable";
            object obj = dao.ExecuteScale("select *from z_Tmp_Timetable");
            if (Check() == true)
            {
                string Confirm = "确认重新生成课表？";
                    
                if (obj == null)
                {
                    Generate();
                    MessageBox.Show("生成课表成功！");
                    log.InfoFormat("生成课表");
                }
                else
                {
                    DialogResult dr = MessageBox.Show(Confirm, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == DialogResult.OK)
                    {                     
                        dao.ExecuteNonQuery(delet);
                        Generate();
                        MessageBox.Show("重新生成课表成功！");
                        log.InfoFormat("重新生成课表");
                    }
                }

            }
            else
            {
                if (obj == null)
                {
                    MessageBox.Show(warning.ToString());
                    MessageBox.Show("生成失败！");
                }
                else
                {
                    MessageBox.Show(warning.ToString());
                    MessageBox.Show("重新生成失败！");
                }                               
            }
            Query();
            
        }
        /// <summary>
        /// 教师休假时间，课程限制函数
        /// </summary>
        /// <param name="x">星期几</param>
        /// <param name="y">第几节课</param>
        /// <param name="CourseNumber">课程编号</param>
        /// <param name="Class">班级</param>
        /// <returns></returns>
        private int TimeOffConstraint(int x, int y, int CourseNumber, int Class)
        {
            string TimeOffB = Converter(x, y);//通过Convert函数获得当前的时间段TimeOffB 
            string sqlNum = "select Cname_ from z_tmp_CourseSum where CID_='" + CourseNumber + "'";
            string Course = dao.ExecuteScale(sqlNum).ToString();//获得当前的课程名称
            string TName = TeacherFinderSEQ(Course, Class);//通过存储过程简化逻辑，找出这门课负责的老师
            string sqlnum = "select count(*)from z_tmp_timetable where class_ = '" + Class + "'";
            int num = Convert.ToInt32(dao.ExecuteScale(sqlnum).ToString());
            string Sql = "select * from Z_tmp_timetable";                     
            DataTable dtGrid = dao.GetDataTable(Sql);           
            int state = 0;
            if (TName == "Missing")//找不到负责该课程的老师，返回-1
            {
                return -1;
            }
            else//若有老师则查找这名老师的休假时间
            {
                string sql = "select TimeOff from z_tmp_teacherinfo where TName_ ='" + TName + "' ";
                string TimeOff = dao.ExecuteScale(sql).ToString();
                if (TimeOffB == "NO")//表明这节课为第五节课，不能安排课程，否则违反了第五节课第六节课不能安排连续课程的规律，返回0
                {                  
                    return 0;
                }
                if (TimeOff == TimeOffB)//若该时间段与该老师休假时间段相同则同样无法安排课程，返回0
                {
                    return 0;
                }
                else//若同时满足上述条件则观察是否存在冲突课程，在这里课程编号3与6相对应的java与c语言冲突
                {
                    
                    if (num == 0 ||( CourseNumber != 3&&CourseNumber != 6))//如果当天没有出现这两节课或者还未给当天排课则返回1
                    {
                        
                        return 1;
                    }

                    if (CourseNumber == 3)//若出现其中一节则查找是否有另外一节课
                    {
                        DataRow[] drList = dtGrid.Select(""+ getString(x)+"= '6'");//在datarow中搜索指定的值
                        if (drList.Length > 0)//有则return-1
                        {
                            state = -1;
                        }

                        if (state == 0)
                        {
                            return 1;
                        }

                        else
                        {                            
                            return 0;
                        }                      
                    }
                    if (CourseNumber == 6)//与上相同
                    {
                        DataRow[] drList = dtGrid.Select("" + getString(x) + "= '3'");
                        if (drList.Length > 0)
                        {
                            state = -1;
                        }
                        if (state == 0)
                        {
                            return 1;
                        }
                        else
                        {                            
                            return 0;
                        }
                    }
                    else
                    {
                        return 0;
                    }
                }                                                   
            }
        }
        /// <summary>
        /// 教师名称获取函数
        /// </summary>
        /// <param name="Course">课程名</param>
        /// <param name="Class">班级</param>
        /// <returns></returns>
        [Obsolete ("this is an old method ,plese use teacherFinderSEQ instead", false)]
        private string TeacherFinder(string Course,int Class)
        {
            string strSql = "select TName_ from z_tmp_TeacherInfo where CClass1 ='Class" + Class + "' and course1_ ='" + Course + "' or CClass1 ='Class" + Class + "' and course2_ ='" + Course + "' or CClass2 ='Class" + Class + "' and course1_ ='" + Course + "' or CClass2 ='Class" + Class + "' and course2_ ='" + Course + "'";
            object obj = dao.ExecuteScale(strSql);            
            if (obj==null)
            {
                string WAR = string.Format("未安排班级：Class{0},{1}的课程；", Class, Course);
                warning.Append(WAR);
                return "Missing";              
            }
            else
            {
                return dao.ExecuteScale(strSql).ToString();
            }          
        }
        /// <summary>
        /// 教师名称获取函数
        /// </summary>
        /// <param name="Course">课程名</param>
        /// <param name="Class">班级</param>
        /// <returns></returns>
        private string TeacherFinderSEQ(string Course,int Class)
        {
            string[] returnparm = new string[3];
            string errinfo = "";
            string sysIxdex = "";
            string sysMessage = "";
            dao.RunProcedure("SP_TMP_TeacherFinder", new OracleParameter[5]  {
                new OracleParameter("v_Course", Course) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_Class", Class) { OracleType = OracleType.Int32, Size=12 },               
                  new OracleParameter("o_retcode", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                  new OracleParameter("o_retmsg", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                  new OracleParameter("o_retmsg1", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar }
               }, out returnparm, out errinfo);//在存储过程中执行查找逻辑

            sysIxdex   = returnparm[0].Trim();
            sysMessage = returnparm[1].Trim();
            if (sysIxdex == "1")
            {
                return sysMessage;
            }
            else
            {
                string WAR = string.Format("未安排班级：Class{0},{1}的课程；", Class, Course);
                warning.Append(WAR); 
                return sysMessage;//若有班级的课程未安排老师则将该信息加到字符串中提示用户
            }            
        }



        /// <summary>
        /// 教师休假时间转换函数
        /// </summary>
        /// <param name="x">星期几</param>
        /// <param name="y">第几节课</param>
        /// <returns></returns>
        /// 
        private string Converter(int x,int y)
        {
            string strInfo="";
            if (y == 4)
            {
                strInfo = "NO";
            }
            else
            {
                switch (x)
                {
                    case 0:
                        if (y < 5)
                            strInfo = "周一上午";
                        else
                            strInfo = "周一下午";
                        break;
                    case 1:
                        if (y < 5)
                            strInfo = "周二上午";
                        else
                            strInfo = "周二下午";
                        break;
                    case 2:
                        if (y < 5)
                            strInfo = "周三上午";
                        else
                            strInfo = "周三下午";
                        break;
                    case 3:
                        if (y < 5)
                            strInfo = "周四上午";
                        else
                            strInfo = "周四下午";
                        break;
                    case 4:
                        if (y < 5)
                            strInfo = "周五上午";
                        else
                            strInfo = "周五下午";
                        break;
                    default:
                        strInfo = "";
                        break;
                }
            }         
            return strInfo;          
        }
        /// <summary>
        /// 判断每节课是否都有老师来上课
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        private bool Check()
        {
            int count = 0;
            int state = 0;
            
            string strSql = "select *  from z_tmp_CourseSum";
            string sqlCount = "select count(*)from z_tmp_CourseSum";
            int Num = Convert.ToInt32(dao.ExecuteScale(sqlCount).ToString());
            string sql = "select count(*)from z_tmp_classinfo";
            int n = Convert.ToInt32(dao.ExecuteScale(sql).ToString());
            DataTable dtGrid = dao.GetDataTable(strSql);
            string[] Name = new string[Num];
            foreach (DataRow dr in dtGrid.Rows)
            {
                Name[count] = dr["CName_"].ToString();
                count++;
            }
            for(int j = 1; j < n + 1; j++)
            {
                for (int i = 0; i < Num; i++)
                {
                    if (TeacherFinderSEQ(Name[i], j) == "Missing")
                    {
                        state = -1;
                    }

                }
            }                        
            if (state == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            

        }
        /// <summary>
        /// 课表生成逻辑函数
        /// </summary>
        /// <param name="n">需要生成课表的班级号</param>
        private void GenerateTiemTable(int n)
        {
            int i = 0;
            int m = n + 2;
            int count = 0;

            long tick = DateTime.Now.Ticks;
            Random ran = new Random((int)(tick & 0xffffffffL) | (int)(tick >> 32));//指定当前时间作为随机数种子可以确保Random类的对象来产生随机数不同

            int[,] course1 = new int[5, 9];

            string sqltext = "select *  from z_tmp_CourseSum";
            string sqlCount = "select count(*)from z_tmp_CourseSum";
            int Num = Convert.ToInt32(dao.ExecuteScale(sqlCount).ToString());
            DataTable dtGrid = dao.GetDataTable(sqltext);
            int[] Name = new int[Num];//定义一个Name数组长度等于z_tmp_CourseSum（课程信息表）中字段的个数Num
            foreach (DataRow dr in dtGrid.Rows)
            {
                Name[count] = int.Parse(dr["CID_"].ToString());
                count++;
            }  //将该信息表中的每一个ID名称写入Name数组当中            

                while (i < Num * 2)//两个相邻班级一起安排课程，当一个课程被安排完之后i数值加1，当两个班课程都安排结束，课程数量i即等于课程总数Num*2;
                {
                    int x = ran.Next(0, 5);//随机数x表示星期数（0—4分别表示周一到周五）
                    int y = ran.Next(0, 9);//随机数y表示第几节课（0—9分别表示第一节课到9节课）
                if (i < Num)//开始排第一个班级
                    {
                        if (y == 8)//当随机到当天最后一节课
                        {
                            if (course1[x, y] == 0 && course1[x, y - 1] == 0)//先判断当前和上一节课是否已经被安排课程，若已经被占用则跳出重新抽取随机数
                            {
                                if (TimeOffConstraint(x, y, Name[i], n) == 1)//TimeOffConstraint函数，判断当前教师在这一时间段是否为休假时间，当天是否有相互冲突的两节课，若有则跳出重新抽取随机数
                            {
                                string strSql = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','7','" + Name[i] + "')";//通过getString（x）函数将随机到数字变成相对应的星期数
                                    string strSql1 = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','8','" + Name[i] + "')";
                                    object obj = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '7'and class_='" + n + "'");
                                    object obj1 = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '8'and class_='" + n + "'");
                                    if (obj == null)
                                    {
                                        dao.ExecuteNonQuery(strSql); //若该天没有已经安排的课程则执行插入操作                            
                                    }
                                    else if (obj != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i] + "'where conum_='7'and class_='" + n + "'");//若该天已经有安排的课程则执行更新操作（要不然就就会出现很多个同样的星期因为不断insert）
                                    }
                                    if (obj1 == null)//因为两节课连续所有在执行一次该操作
                                    {
                                        dao.ExecuteNonQuery(strSql1);
                                    }
                                    else if (obj1 != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i] + "'where conum_='8'and class_='" + n + "'");
                                    }
                                    course1[x, y] = 1;
                                    course1[x, y - 1] = 1;
                                    i++;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else//若没有随机到最后一节课则正常执行与上相同
                        {
                            if (course1[x, y] == 0 && course1[x, y + 1] == 0)
                            {
                                if (TimeOffConstraint(x, y, Name[i], n) == 1)
                                {
                                    int t = y + 1;
                                    string strSql = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','" + y + "','" + Name[i] + "')";
                                    string strSql1 = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','" + t + "','" + Name[i] + "')";
                                    object obj = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '" + y + "'and class_='" + n + "'");
                                    object obj1 = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '" + t + "'and class_='" + n + "'");
                                    if (obj == null)
                                    {
                                        dao.ExecuteNonQuery(strSql);

                                    }
                                    else if (obj != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i] + "'where conum_='" + y + "'and class_='" + n + "'");
                                    }
                                    if (obj1 == null)   
                                    {
                                        dao.ExecuteNonQuery(strSql1);
                                    }
                                    else if (obj1 != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i] + "'where conum_='" + t + "'and class_='" + n + "'");
                                    }
                                    course1[x, y] = 1;
                                    course1[x, y + 1] = 1;
                                    i++;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }

                    }
                    else//第二个班级，这时i>Num，重复上操作
                    {
                        if (y == 8)
                        {
                            if (course1[x, y] == 0 && course1[x, y - 1] == 0)
                            {
                                if (TimeOffConstraint(x, y, Name[i - Num], n) == 1)
                                {
                                    string strSql = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','7','" + Name[i - Num] + "')";
                                    string strSql1 = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','8','" + Name[i - Num] + "')";
                                    object obj = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '7'and class_='" + n + "'");
                                    object obj1 = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '8'and class_='" + n + "'");
                                    if (obj == null)
                                    {
                                        dao.ExecuteNonQuery(strSql);


                                    }
                                    else if (obj != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i - Num] + "'where conum_='7'and class_='" + n + "' ");

                                    }
                                    if (obj1 == null)
                                    {
                                        dao.ExecuteNonQuery(strSql1);

                                    }
                                    else if (obj1 != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i - Num] + "'where conum_='8'and class_='" + n + "'");

                                    }
                                    course1[x, y] = 1;
                                    course1[x, y - 1] = 1;
                                    i++;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            if (course1[x, y] == 0 && course1[x, y + 1] == 0)
                            {
                                if (TimeOffConstraint(x, y, Name[i - Num], n) == 1)
                                {
                                    int t = y + 1;
                                    string strSql = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','" + y + "','" + Name[i - Num] + "')";
                                    string strSql1 = "insert into z_tmp_timetable(class_,conum_," + getString(x) + ")values('" + n + "','" + t + "','" + Name[i - Num] + "')";
                                    object obj = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '" + y + "'and class_='" + n + "'");
                                    object obj1 = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '" + t + "'and class_='" + n + "'");
                                    if (obj == null)
                                    {
                                        dao.ExecuteNonQuery(strSql);



                                    }
                                    else if (obj != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i - Num] + "'where conum_='" + y + "'and class_='" + n + "'");

                                    }
                                    if (obj1 == null)
                                    {
                                        dao.ExecuteNonQuery(strSql1);

                                    }
                                    else if (obj1 != null)
                                    {
                                        dao.ExecuteNonQuery("update z_tmp_timetable set " + getString(x) + "='" + Name[i - Num] + "'where conum_='" + t + "'and class_='" + n + "'");

                                    }
                                    course1[x, y] = 1;
                                    course1[x, y + 1] = 1;
                                    i++;
                                }
                                else
                                {
                                    continue;
                                }

                            }
                        }
                    }
                }

                for (int q = 0; q < 9; q++)//最后将所有没有随机到的节数加上空白
                {
                    object objM1 = dao.ExecuteScale("select * from z_tmp_timetable where conum_ = '" + q + "'and class_='" + n + "'");
                    if (objM1 == null)
                    {
                        string sql = "insert into z_tmp_timetable(class_,conum_,mon_,tue_,wed_,thur_,fri_)values('" + n + "','" + q + "','','','','','')";
                        dao.ExecuteNonQuery(sql);
                    }
                }                                     
        }      
        /// <summary>
        /// 确认所需添加课程的星期
        /// </summary>
        /// <param name="b">对应的星期几</param>
        /// <returns></returns>
        static string getString(int b)
        {
            string str;
            switch (b)
            {
                case 0:
                    str = "MON_";
                    break;
                case 1:
                    str = "TUE_";
                    break;
                case 2:
                    str = "WED_";
                    break;
                case 3:
                    str = "THUR_";
                    break;
                case 4:
                    str = "FRI_";
                    break;
                default:
                    str = "";
                    break;
            }
            return str;                   
        }
        /// <summary>
        /// 查找动作按钮
        /// </summary> 
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strClass = txtClass.Text.Trim();
            string strNum = txtCnum.Text.Trim();
            StringBuilder strSql = new StringBuilder();
            if (strClass.Length != 0)
            {
                strSql.Append(" where ClassN_ like '%" + strClass + "%'");
            }
            if (strNum.Length != 0)
            {
                if (strSql.Length == 0)
                {
                    strSql.Append(" where conum_ ='" + strNum + "'");
                }
                else
                {
                    strSql.Append(" and conum_='" + strNum + "'");
                }
            }
            StringBuilder str = new StringBuilder();
            str.Append("select z.classn_,t.conum_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.mon_) as mon_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.tue_) as tue_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.wed_) as wed_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.thur_) as thur_,");
            str.Append("(select c.cname_ || '(' || (select distinct e.tname_ from z_Tmp_Teacherinfo e where(e.cclass1 = z.classn_ and e.course1_ = c.cname_) or(e.course2_ = c.cname_ and e.cclass2 = z.classn_) or(e.cclass1 = z.classn_ and e.course2_ = c.cname_)or(e.cclass2 = z.classn_ and e.course1_ = c.cname_)  ) || ')'  from z_tmp_coursesum c where c.cid_ = t.fri_) as fri_");
            str.Append(" from z_tmp_timetable t, z_Tmp_Classinfo z where t.class_ = z.id)");
            string sql = "select  * from( " + str.ToString() + strSql + " order by classN_,conum_";
            DataTable dtUser = dao.GetDataTable(sql);
            grdView.DataSource = dtUser;
          
            foreach (DataGridViewColumn dc in grdView.Columns)//控制datagrid中列的visiable属性进行星期检索
            {                                    
                string[] weekdays = { "MON_", "TUE_", "WED_", "THUR_", "FRI_" };
                if (CboxDay.SelectedIndex != 0)
                {
                    foreach (string i in weekdays)
                    {
                        grdView.Columns[i].Visible = false;
                        grdView.Columns[weekdays[CboxDay.SelectedIndex - 1]].Visible = true;                      
                    }
                }
                else
                {
                    foreach (string i in weekdays)
                    {
                        {
                            grdView.Columns[i].Visible = true;
                        }
                    }
                }               
            }
        }
        /// <summary>
        /// 离开按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
           Close();
        }
    }
}
