﻿using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Win.Data;

namespace WinDemo
{
    public partial class SubCourse : Form
    {
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
        int state = 0;
        string[] arr= new string[2];
        public SubCourse()
        {
            InitializeComponent();
        }
        private void SubCourse_Load(object sender, EventArgs e)
        {
            if (state == 1)
            {
                this.Text = "添加用户";
                arr[0] = "1";
            }
            if (state == 2)
            {
                this.Text = "修改用户";
                lbCID.Text = "课程编号：" + arr[0];
                txtCNAME.Text = arr[1];
            }
        }
        /// <summary>
        /// 获取状态值函数
        /// </summary>
        /// <param name="state">状态值</param>
        public void getState(int state)
        {
            this.state = state;
        }
        /// <summary>
        /// 获取选定的信息所形成的数组
        /// </summary>
        /// <param name="arr">选定信息所形成的数组</param>
        public void getarr(string[] arr)
        {
            this.arr = arr;
        }      
        /// <summary>
        /// 离开函数按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
           Close();
        }
        /// <summary>
        /// 提交函数按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string strCName = txtCNAME.Text.Trim();                      
                if (strCName.Length == 0)
                {
                    MessageBox.Show("请输入课程名称");
                    return;
                }
                int Cou = 0;           
                try
                {
                    string[] returnparm = new string[2];
                    string errinfo = "";
                    string sysIxdex = "";
                    string sysMessage = "";
                    dao.RunProcedure("SP_TMP_Test1", new OracleParameter[5]  {
                  new OracleParameter("v_State", state) { OracleType = OracleType.Int32, Size=12 },
                   new OracleParameter("v_Id", arr[0]) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_Name", strCName) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("o_retcode", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                  new OracleParameter("o_retmsg", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar }
               }, out returnparm, out errinfo);

                    sysIxdex = returnparm[0].Trim();
                    sysMessage = returnparm[1].Trim();
                    MessageBox.Show(sysMessage);
                    Cou = int.Parse(sysIxdex);
                }
                catch (Exception ex)
                {
                    log.Error(ex);
                }

                if (Cou == 1)
                {               
                    Close();
                    log.InfoFormat("添加用户{0}", strCName);
                }
                if (Cou == 2)
                {
                   Close();
                   log.Debug("修改操作");
                 }                  
        }     
    }
}
