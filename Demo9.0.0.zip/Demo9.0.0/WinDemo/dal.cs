﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinDemo;
using Win.Data;
using System.Windows.Forms;

namespace DAL
{
    public class dal
    {
       public int login(string username, string password)
        {
            dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
            string str0 = "select username_ from z_tmp_user123 where username_='" + username + "'";

            object result = dao.ExecuteScale(str0) ;
            if (result ==null)
            {
               
                return 0;
            }
            else
            {
                string str1 = "select * from z_tmp_user123 where username_='" + username + "' and password_ = '" + password + "'";
                object result1 = dao.ExecuteScale(str1);
                if (result1 == null)
                {
                    return 1;
                }
                else
                {
                    return 2;
                }
            }
        }


        public int signup(string username, string password)
        {
            dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
            string str0 = "select username_ from z_tmp_user123 where username_='" + username + "'";

            object result = dao.ExecuteScale(str0);
            if (result == null)
            {
                string str = "insert into z_tmp_user123 (username_,password_) values('" + username + "','" + password + "')";
                dao.ExecuteNonQuery(str);
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }
}
