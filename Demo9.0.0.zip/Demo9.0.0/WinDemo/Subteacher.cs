﻿using log4net;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Win.Data;

namespace WinDemo
{
    public partial class SubTeacher : Form
    {
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
        int states = 0;
        string[] arr = new string[7];
        private void SubTeacher_Load(object sender, EventArgs e)
        {
            string strsql = ("select * from z_tmp_COURSESUM order by CID_");
            string strDay = ("select * from z_tmp_TimeOff");
            string strClass = ("select * from z_tmp_Classinfo");
            DataTable dt1 = dao.GetDataTable(strsql);
            DataTable dt2 = dao.GetDataTable(strsql);
            DataTable dt3 = dao.GetDataTable(strDay);
            DataTable dt4 = dao.GetDataTable(strClass);
            DataTable dt5 = dao.GetDataTable(strClass);

            CoBoxC1.DataSource = dt1;
            DataRow dr1 = dt1.NewRow();
            dr1["CName_"] = "无";
            dt1.Rows.InsertAt(dr1, 0);
            CoBoxC1.DisplayMember = "CName_";
            CoBoxC1.ValueMember = "CID_";

            CoBoxC2.DataSource = dt2;
            DataRow dr2 = dt2.NewRow();
            dr2["CName_"] = "无";
            dt2.Rows.InsertAt(dr2, 0);
            CoBoxC2.DisplayMember = "CName_";
            CoBoxC2.ValueMember = "CID_";

            CoBoxDay.DataSource = dt3;
            CoBoxDay.DisplayMember = "Day_";
            CoBoxDay.ValueMember = "id_";

            CoBoxCL1.DataSource = dt4;
            DataRow dr4 = dt4.NewRow();
            dr4["ClassN_"] = "无";
            dt4.Rows.InsertAt(dr4, 0);
            CoBoxCL1.DisplayMember = "ClassN_";
            CoBoxCL1.ValueMember = "ClassN_";


            CoBoxCL2.DataSource = dt5;
            DataRow dr5 = dt5.NewRow();
            dt5.Rows.InsertAt(dr5, 0);
            dr5["ClassN_"] = "无";
            CoBoxCL2.DisplayMember = "ClassN_";
            CoBoxCL2.ValueMember = "ClassN_";
            if (states == 1)//当传入的参数等于1的时候，即代表增加字段
            {
                Text = "添加教师信息";//修改标题
                arr[0] = "1";
            }
            if (states == 2)//当传入的参数等于1的时候，即代表修改字段
            {
                Text = "修改教师信息";
                if (arr[2] == "")
                {
                    arr[2] = "无";
                }
                if (arr[3] == "")
                {
                    arr[3] = "无";
                }
                if (arr[5] == "")
                {
                    arr[5] = "无";
                }
                if (arr[6] == "")
                {
                    arr[6] = "无";
                }
                lbID.Text = "编号：" + arr[0];
                txtName.Text = arr[1];
                CoBoxC1.Text = arr[2];
                CoBoxC2.Text = arr[3];
                CoBoxDay.Text = arr[4];
                CoBoxCL1.Text = arr[5];
                CoBoxCL2.Text = arr[6];//读取当前字段并填入

            }


        }
        public SubTeacher()
        {
            InitializeComponent();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.skinEngine1.SkinFile = Application.StartupPath + "//OneCyan.ssk";
        }
        /// <summary>
        /// 获取有教师表传来的状态是更新还是插入
        /// </summary>
        /// <param name="i">状态值</param>
        public void getState(int i)
        {
            states = i;
        }
        /// <summary>
        /// 在更新时获取当前选中值的信息
        /// </summary>
        /// <param name="arr">由当前选中值的信息形成的集合</param>
        public void getArry(string[] arr)
        {
            this.arr = arr;
        }
        /// <summary>
        /// 检测当前更新或者新插入的值是否已存在
        /// </summary>
        /// <param name="strC1">输入的第一节课程</param>
        /// <param name="strC2">输入的第二节课程</param>
        /// <param name="strCL1">负责的第一个班级</param>
        /// <param name="strCL2">负责的第二个班级</param>
        /// <returns></returns>
        private int SequenceCheck(string strC1, string strC2, string strCL1, string strCL2, string tname, string timeoff,int states)
        {
            string[] returnparm = new string[2];
            string errinfo = "";
            string sysIxdex = "";
            string sysMessage = "";
            dao.RunProcedure("SP_TMP_OccupyCheck", new OracleParameter[10]  {
                  new OracleParameter("v_state", states) { OracleType = OracleType.Int32, Size=12 },
                  new OracleParameter("v_tid", arr[0]) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_course1", strC1) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_course2", strC2) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_class1", strCL1) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_class2", strCL2) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_tname", tname) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("v_timeoff", timeoff) { OracleType = OracleType.VarChar, Size=12 },
                  new OracleParameter("o_retcode", OracleType.VarChar,10) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                  new OracleParameter("o_retmsg", OracleType.VarChar,20) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar }
               }, out returnparm, out errinfo);         
            sysIxdex = returnparm[0].Trim();
            sysMessage = returnparm[1].Trim();
            MessageBox.Show(sysMessage);
            return int.Parse(sysIxdex);
        }        
        /// <summary>
        /// 退出动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
           Close();
        }
        /// <summary>
        /// 保存动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string strName = txtName.Text.Trim();
            string strC1 = CoBoxC1.Text.Trim();
            string strC2 = CoBoxC2.Text.Trim();
            string strDay = CoBoxDay.Text.Trim();
            string strCL1 = CoBoxCL1.Text.Trim();
            string strCL2 = CoBoxCL2.Text.Trim();
            if (txtName.Text == arr[1] && CoBoxC1.Text == arr[2] && CoBoxC2.Text == arr[3] && CoBoxDay.Text == arr[4] && CoBoxCL1.Text == arr[5] && CoBoxCL2.Text == arr[6])
            {
                Close();
                return;               
            }

            if (txtName.Text == arr[1] && CoBoxC1.Text == arr[3] && CoBoxC2.Text == arr[2] && CoBoxDay.Text == arr[4] && CoBoxCL1.Text == arr[6] && CoBoxCL2.Text == arr[5])
            {
                Close();           
                return;
            }
            if (txtName.Text == arr[1] && CoBoxC1.Text == arr[2] && CoBoxC2.Text == arr[3] && CoBoxDay.Text == arr[4] && CoBoxCL1.Text == arr[5] && CoBoxCL2.Text == arr[6])
            {
                Close();
                return;
            }

            if (strName.Length == 0)
            {
                MessageBox.Show("请输入姓名");
                return;
            }

            if (strC1 == strC2)
            {
                MessageBox.Show("所选择的两门课程不能相同！");
                return;
            }
            if (strCL1 == strCL2)
            {
                MessageBox.Show("所选择的两负责班级不能相同！");
                return;
            }
            int i = 3; 
            try
            {
               i= SequenceCheck(strC1, strC2, strCL1, strCL2, strName, strDay, states);
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
            if (i == 0)
            {
                string message = string.Format("{0},{1}班级已存在负责课程{2}或{3}的老师", strCL1, strCL2, strC1, strC2);
                MessageBox.Show(message);
            }
            if (i == 1)
            {
                Close();
                log.InfoFormat("添加用户{0}", strName);
            }
            if (i == 2)
            {
                Close();
                log.InfoFormat("修改用户编号{0}", arr[0]);
            }
     
        }
    }
}
                
      