﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Win.Data;


namespace BLL
{
    public class bll
    {
        DAL.dal dal = new DAL.dal();

        public int userCheck(MODEL.model m_userinfo)
        {
            return dal.login(m_userinfo.username, m_userinfo.password);
        }

        public int addUser(MODEL.model m_userinfo)
        {
            return dal.signup(m_userinfo.username, m_userinfo.password);
        }
    }


}
