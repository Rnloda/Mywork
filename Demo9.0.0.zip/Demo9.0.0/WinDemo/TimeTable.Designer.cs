﻿namespace WinDemo
{
    partial class TimeTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grdView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.CboxDay = new System.Windows.Forms.ComboBox();
            this.lbDay = new System.Windows.Forms.Label();
            this.txtCnum = new System.Windows.Forms.TextBox();
            this.lbCnum = new System.Windows.Forms.Label();
            this.lbClass = new System.Windows.Forms.Label();
            this.txtClass = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine();
            this.ClassN_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CONUM_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MON_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TUE_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WED_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.THUR_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FRI_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.grdView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grdView
            // 
            this.grdView.AllowUserToAddRows = false;
            this.grdView.AllowUserToDeleteRows = false;
            this.grdView.AllowUserToResizeColumns = false;
            this.grdView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grdView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grdView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClassN_,
            this.CONUM_,
            this.MON_,
            this.TUE_,
            this.WED_,
            this.THUR_,
            this.FRI_});
            this.grdView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdView.Location = new System.Drawing.Point(3, 17);
            this.grdView.MultiSelect = false;
            this.grdView.Name = "grdView";
            this.grdView.ReadOnly = true;
            this.grdView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grdView.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.grdView.RowTemplate.Height = 23;
            this.grdView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdView.Size = new System.Drawing.Size(1162, 593);
            this.grdView.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnExit);
            this.groupBox1.Controls.Add(this.btnGenerate);
            this.groupBox1.Controls.Add(this.CboxDay);
            this.groupBox1.Controls.Add(this.lbDay);
            this.groupBox1.Controls.Add(this.txtCnum);
            this.groupBox1.Controls.Add(this.lbCnum);
            this.groupBox1.Controls.Add(this.lbClass);
            this.groupBox1.Controls.Add(this.txtClass);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Location = new System.Drawing.Point(9, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1165, 58);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(1084, 20);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 37;
            this.btnExit.Text = "返回";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(589, 20);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(75, 23);
            this.btnGenerate.TabIndex = 36;
            this.btnGenerate.Text = "生成课表";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // CboxDay
            // 
            this.CboxDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CboxDay.FormattingEnabled = true;
            this.CboxDay.Items.AddRange(new object[] {
            "All",
            "一",
            "二",
            "三",
            "四",
            "五"});
            this.CboxDay.Location = new System.Drawing.Point(381, 20);
            this.CboxDay.Name = "CboxDay";
            this.CboxDay.Size = new System.Drawing.Size(111, 20);
            this.CboxDay.TabIndex = 35;
            // 
            // lbDay
            // 
            this.lbDay.AutoSize = true;
            this.lbDay.Location = new System.Drawing.Point(334, 25);
            this.lbDay.Name = "lbDay";
            this.lbDay.Size = new System.Drawing.Size(41, 12);
            this.lbDay.TabIndex = 34;
            this.lbDay.Text = "星期：";
            // 
            // txtCnum
            // 
            this.txtCnum.Location = new System.Drawing.Point(217, 20);
            this.txtCnum.MaxLength = 20;
            this.txtCnum.Name = "txtCnum";
            this.txtCnum.Size = new System.Drawing.Size(111, 21);
            this.txtCnum.TabIndex = 32;
            // 
            // lbCnum
            // 
            this.lbCnum.AutoSize = true;
            this.lbCnum.Location = new System.Drawing.Point(170, 25);
            this.lbCnum.Name = "lbCnum";
            this.lbCnum.Size = new System.Drawing.Size(41, 12);
            this.lbCnum.TabIndex = 31;
            this.lbCnum.Text = "节数：";
            // 
            // lbClass
            // 
            this.lbClass.AutoSize = true;
            this.lbClass.Location = new System.Drawing.Point(6, 25);
            this.lbClass.Name = "lbClass";
            this.lbClass.Size = new System.Drawing.Size(41, 12);
            this.lbClass.TabIndex = 30;
            this.lbClass.Text = "班级：";
            // 
            // txtClass
            // 
            this.txtClass.Location = new System.Drawing.Point(53, 20);
            this.txtClass.MaxLength = 20;
            this.txtClass.Name = "txtClass";
            this.txtClass.Size = new System.Drawing.Size(111, 21);
            this.txtClass.TabIndex = 29;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(508, 20);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "查询课表";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.grdView);
            this.groupBox2.Location = new System.Drawing.Point(9, 72);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1168, 613);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // skinEngine1
            // 
            this.skinEngine1.@__DrawButtonFocusRectangle = true;
            this.skinEngine1.DisabledButtonTextColor = System.Drawing.Color.Gray;
            this.skinEngine1.DisabledMenuFontColor = System.Drawing.SystemColors.GrayText;
            this.skinEngine1.InactiveCaptionColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinFile = null;
            // 
            // ClassN_
            // 
            this.ClassN_.DataPropertyName = "ClassN_";
            this.ClassN_.HeaderText = "班级";
            this.ClassN_.Name = "ClassN_";
            this.ClassN_.ReadOnly = true;
            // 
            // CONUM_
            // 
            this.CONUM_.DataPropertyName = "CONUM_";
            this.CONUM_.HeaderText = "节数";
            this.CONUM_.Name = "CONUM_";
            this.CONUM_.ReadOnly = true;
            // 
            // MON_
            // 
            this.MON_.DataPropertyName = "MON_";
            this.MON_.HeaderText = "星期一";
            this.MON_.Name = "MON_";
            this.MON_.ReadOnly = true;
            this.MON_.Width = 180;
            // 
            // TUE_
            // 
            this.TUE_.DataPropertyName = "TUE_";
            this.TUE_.HeaderText = "星期二";
            this.TUE_.Name = "TUE_";
            this.TUE_.ReadOnly = true;
            this.TUE_.Width = 180;
            // 
            // WED_
            // 
            this.WED_.DataPropertyName = "WED_";
            this.WED_.HeaderText = "星期三";
            this.WED_.Name = "WED_";
            this.WED_.ReadOnly = true;
            this.WED_.Width = 180;
            // 
            // THUR_
            // 
            this.THUR_.DataPropertyName = "THUR_";
            this.THUR_.HeaderText = "星期四";
            this.THUR_.Name = "THUR_";
            this.THUR_.ReadOnly = true;
            this.THUR_.Width = 180;
            // 
            // FRI_
            // 
            this.FRI_.DataPropertyName = "FRI_";
            this.FRI_.HeaderText = "星期五";
            this.FRI_.Name = "FRI_";
            this.FRI_.ReadOnly = true;
            this.FRI_.Width = 180;
            // 
            // TimeTable
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1180, 697);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TimeTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "课表查询";
            this.Load += new System.EventHandler(this.TimeTable_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView grdView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lbDay;
        private System.Windows.Forms.TextBox txtCnum;
        private System.Windows.Forms.Label lbCnum;
        private System.Windows.Forms.Label lbClass;
        private System.Windows.Forms.TextBox txtClass;
        private System.Windows.Forms.ComboBox CboxDay;
        private System.Windows.Forms.Button btnGenerate;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClassN_;
        private System.Windows.Forms.DataGridViewTextBoxColumn CONUM_;
        private System.Windows.Forms.DataGridViewTextBoxColumn MON_;
        private System.Windows.Forms.DataGridViewTextBoxColumn TUE_;
        private System.Windows.Forms.DataGridViewTextBoxColumn WED_;
        private System.Windows.Forms.DataGridViewTextBoxColumn THUR_;
        private System.Windows.Forms.DataGridViewTextBoxColumn FRI_;
    }
}