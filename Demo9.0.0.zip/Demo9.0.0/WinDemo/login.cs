﻿using BLL;
using MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Win.Data;
using WinDemo;
using log4net;



namespace WindowsFormsApp6
{
   
    public partial class Form1 : Form
    {
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //实例化model层中 userInfo类用于传递数据  
        MODEL.model m_userinfro = new MODEL.model();

        //实例化BAL层中 userAccess方法衔接用户输入与数据库匹配  
        BLL.bll b_userAccess = new BLL.bll();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            m_userinfro.username = txtName.Text.Trim();
            m_userinfro.password = txtPwd.Text.Trim();
            if (b_userAccess.userCheck(m_userinfro) == 0)
            {
                MessageBox.Show("不存在该用户");
            }
            if (b_userAccess.userCheck(m_userinfro) == 1)
            {
                MessageBox.Show("密码错误");
            }
            if (b_userAccess.userCheck(m_userinfro) == 2)
            {
                MessageBox.Show("登入成功");
                Main main = new Main();
                main.ShowDialog();
                log.InfoFormat("用户{0}登入", m_userinfro.username);
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            m_userinfro.username = txtName.Text.Trim();
            m_userinfro.password = txtPwd.Text.Trim();
            if (b_userAccess.addUser(m_userinfro) == 0)
            {
                MessageBox.Show("新建用户成功");
                log.InfoFormat("新建用户{0}", m_userinfro.username);
            }
            else
            {
                MessageBox.Show("已存在该用户");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ComClass com = new ComClass();
            DataTable dtConfig = com.GetDataSourceTable();

            DataRow[] drSmzq = dtConfig.Select("DANAME_='TestDB'");
            if (drSmzq.Length != 1)
            {
                MessageBox.Show("生命周期数据源配置错误！");
                return;
            }
            ComClass.m_DB_Source = drSmzq[0]["DASOURCE_"].ToString().Trim();
            ComClass.m_DB_User = drSmzq[0]["USER_"].ToString().Trim();
            ComClass.m_DB_Pwd = PWDEncrypt.Decrypt(drSmzq[0]["PAS_"].ToString().Trim());


            string strProcess = Process.GetCurrentProcess().Id.ToString();
            this.Text = "测试系统  进程ID:" + strProcess;
            string strAdd = ComClass.GetMacAddress();
            ComClass.m_Win32Or64 = ComClass.Distinguish64or32System();

            log.InfoFormat("操作系统：{0}位,客户端IP地址:{1},Mac地址:{2}。", ComClass.m_Win32Or64, ComClass.m_Client_Ip, strAdd);
        }
    }
}

