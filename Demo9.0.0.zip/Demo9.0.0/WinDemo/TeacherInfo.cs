﻿using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Win.Data;

namespace WinDemo
{
    public partial class TeacherInfo : Form
    {
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
        int n_Id;
        public TeacherInfo()
        {
            InitializeComponent();
            ComClass com = new ComClass();
            com.DoubleBufferedGrid(grdview, true);
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.skinEngine1.SkinFile = Application.StartupPath + "//DiamondBlue.ssk";
        }
        /// <summary>
        /// 删除课表函数
        /// </summary>
        private void deleteTable()
        {
            string sql = "delete from z_tmp_TimeTable";
            dao.ExecuteNonQuery(sql);
        }
        /// <summary>
        /// 查找动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strID = txtID.Text.Trim();
            string strName = txtName.Text.Trim();
            string strCourse = txtCourse.Text.Trim();
            string strDay = txtTimeOff.Text.Trim();           
            StringBuilder strSql = new StringBuilder();//新建的StringBuild可以随时向其中添加sql语句
            if (strID.Length != 0)//若查找ID框体不为空，添加查找IDsql语句
            {
                strSql.Append(" TID_ like '%"+ strID + "%'");
            }
            if (strName.Length != 0)//若查找名字框不为空
            {
                if (strSql.Length == 0)
                {
                    strSql.Append(" Tname_ like '%" + strName + "%'");//若这个strSql为空则可以直接添加查找语句
                }
                else
                {
                    strSql.Append(" and Tname_ like '%" + strName + "%'");//若不为空则需要加上链接词and
                }
            }
            
            if (strDay.Length != 0)//以下同理
            {
                if (strSql.Length == 0)
                {
                    strSql.Append(" timeoff like '%" + strDay + "%'");
                }
                else
                {
                    strSql.Append(" and timeoff like '%" + strDay + "%'");
                }
            }         
            if (strCourse.Length != 0)
            {
                if (strSql.Length == 0)
                {
                    strSql.Append(" course1_ like '%" + strCourse + "%' or "+strSql.Replace("where","")+"course2_ like '%" + strCourse + "%'");
                }
                else
                {
                    strSql.Append(" and course1_ like '%" + strCourse + "%' or "+ strSql.Replace("where","") + "and course2_ like '%" + strCourse + "%'");
                }
                
            }
            string str = "select *from Z_TMP_TeacherInfo where" + strSql + " order by tid_";//最后加上select开头就可以了
            DataTable dtUser = dao.GetDataTable(str);
            grdview.DataSource = dtUser;//打印表

        }          
        private void TeacherInfo_Load(object sender, EventArgs e)
        {
            Query();
        }
        /// <summary>
        /// 添加教师动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnadd_Click(object sender, EventArgs e)
        {
            string Confirm = "增加教师需重新生成课表，确认继续修改？";
            DialogResult dr = MessageBox.Show(Confirm, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                deleteTable();
                SubTeacher addform = new SubTeacher();
                addform.getState(1);
                addform.ShowDialog();
            }
            Query();
        }
        /// <summary>
        /// 修改教师信息动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAlter_Click(object sender, EventArgs e)
        {
            string Confirm = "修改教师需要重新生成课表，确认继续修改？";
            DialogResult dr = MessageBox.Show(Confirm, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                deleteTable();
                string sql = "select * from Z_tmp_teacherinfo";
                object obj = dao.ExecuteScale(sql);
                if (obj == null)
                {
                    MessageBox.Show("当前数据库没有数据！");
                }
                else
                {
                    if (grdview.DataSource == null)
                    {
                        MessageBox.Show("请选中要修改的行！");
                        Query();
                    }
                    else
                    {
                        string[] arr = new string[7];
                        for (int i = 0; i < 7; i++)
                        {
                            arr[i] = grdview[i, grdview.SelectedCells[i].RowIndex].Value.ToString();
                        }
                        SubTeacher alter = new SubTeacher();
                        alter.getState(2);
                        alter.getArry(arr);
                        alter.ShowDialog();
                    }
                }
                Query();
            }
            int n = grdview.Rows.Count;
            int nSelectRow = 0;
            for (int i = 0; i < n; i++)
            {
                int nCode = int.Parse(grdview.Rows[i].Cells["TID_"].Value.ToString());
                if (nCode == n_Id)
                {
                    grdview.Rows[i].Selected = true;
                    nSelectRow = i;
                }
            }
            if (nSelectRow > 18)
            {
                nSelectRow = nSelectRow - 12;
                grdview.FirstDisplayedScrollingRowIndex = grdview.Rows[nSelectRow].Index;
            }
        }
        /// <summary>
        /// 整表查询函数
        /// </summary>
        private void Query()
        {
            string strsql = ("select * from z_tmp_teacherinfo t order by tid_");
            DataTable dtUser = dao.GetDataTable(strsql);
            grdview.DataSource = dtUser;
        }
        /// <summary>
        /// 删除教师信息按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            string ConfirmF = "删除教师需要重新生成课表，确认继续修改？";
            DialogResult dr1 = MessageBox.Show(ConfirmF, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr1 == DialogResult.OK)
            {
                deleteTable();
                string sql = "select * from Z_tmp_teacherinfo";
                object obj = dao.ExecuteScale(sql);
                if (obj == null)
                {
                    MessageBox.Show("当前数据库没有数据！");
                }
                else
                {
                    if (grdview.DataSource == null)
                    {
                        MessageBox.Show("请选中要删除的数据!");
                    }
                    else
                    {
                        string Confirm = string.Format("确认删除教师{0}，编号{1}?", grdview[1, grdview.SelectedCells[1].RowIndex].Value.ToString(), grdview[0, grdview.SelectedCells[0].RowIndex].Value.ToString());
                        DialogResult dr = MessageBox.Show(Confirm, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                        if (dr == DialogResult.OK)
                        {
                            string[] returnparm = new string[2];
                            string errinfo = "";
                            string sysMessage = "";
                            string sysIndex = "";
                            dao.RunProcedure("SP_TMP_TeacherDELETE", new OracleParameter[3]  {
                            new OracleParameter("v_Id", grdview[0, grdview.SelectedCells[0].RowIndex].Value.ToString()) { OracleType = OracleType.Int32, Size=12 },
                            new OracleParameter("o_retcode", OracleType.VarChar,20) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                            new OracleParameter("o_retmsg", OracleType.VarChar,20) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar }
                            }, out returnparm, out errinfo);
                            sysIndex = returnparm[0];
                            sysMessage = returnparm[1];
                            MessageBox.Show(sysMessage);
                            string id_ = grdview[0, grdview.SelectedCells[0].RowIndex].Value.ToString();
                            string name = grdview[1, grdview.SelectedCells[1].RowIndex].Value.ToString();
                            log.InfoFormat("删除：编号{0},姓名{1}", id_, name);
                        }
                    }
                }
            }    
            Query();
        }

        /// <summary>
        /// 双击gridView触发修改函数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void grdview_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string Confirm = "修改教师需要重新生成课表，确认继续修改？";
            DialogResult dr = MessageBox.Show(Confirm, "确认", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (dr == DialogResult.OK)
            {
                deleteTable();
                string[] arr = new string[7];
                for (int i = 0; i < 7; i++)
                {
                    arr[i] = grdview[i, grdview.SelectedCells[i].RowIndex].Value.ToString();
                }
                SubTeacher alter = new SubTeacher();
                alter.getState(2);
                alter.getArry(arr);
                alter.ShowDialog();
            }
            Query();
            int n = grdview.Rows.Count;
            int nSelectRow = 0;
            for (int i = 0; i < n; i++)
            {
                int nCode = int.Parse(grdview.Rows[i].Cells["TID_"].Value.ToString());
                if (nCode == n_Id)
                {
                    grdview.Rows[i].Selected = true;
                    nSelectRow = i;
                }
            }

            if (nSelectRow > 18)
            {
                nSelectRow = nSelectRow - 12;
                grdview.FirstDisplayedScrollingRowIndex = grdview.Rows[nSelectRow].Index;
            }
        }
        /// <summary>
        /// 离开动作按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEixt_Click(object sender, EventArgs e)
        {
           Close();
        }
        private void grdview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int nRow = e.RowIndex;
            if (nRow < 0)
                return;
            n_Id = int.Parse(grdview.Rows[nRow].Cells["TID_"].Value.ToString());
        }
    }
}
