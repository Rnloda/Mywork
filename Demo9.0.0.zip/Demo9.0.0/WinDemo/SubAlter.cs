﻿using System;
using log4net;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Reflection;
using Win.Data;
using System.Windows.Forms;
using System.Data.OracleClient;

namespace WinDemo
{
    public partial class SubAlter : Form
    {
        ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        dbIntface dao = dbFactory.GetDataBase(ComClass.m_DB_Source, ComClass.m_DB_User, ComClass.m_DB_Pwd);
        string[] arr = new string[7];
        private int status;
        public SubAlter()
        {
            InitializeComponent();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.skinEngine1.SkinFile = Application.StartupPath + "//OneCyan.ssk";
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }   
        public String[] getArry(string[] arr)
        {
            return this.arr = arr;
        }
        public int getStatus(int status)
        {
            return this.status = status;
        }
        private void SubAlter_Load(object sender, EventArgs e)
        { 
            if(status == 0)
            {
                this.Text = "添加用户";
                arr[0] = "0";
            }
            else
            {               
                lbID.Text = "编号:" + arr[0];
                txtName.Text = arr[1];
                txtDep.Text = arr[2];
                txtCountry.Text = arr[3];
                txtPhone.Text = arr[4];
                if (arr[6] == "男")
                {
                    comboBox1.SelectedIndex = 0;
                }
                else
                {
                    comboBox1.SelectedIndex = 1;
                }
            }        
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string strUserName = txtName.Text.Trim();
            string strUserDep = txtDep.Text.Trim();
            string strUserPhone = txtPhone.Text.Trim();
            string strUserCountry = txtCountry.Text.Trim();
            string strGED = "";
            if (comboBox1.SelectedIndex == 0)
            {
                strGED = "男";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                strGED = "女";
            }
            if (strUserName.Length == 0)
            {
                MessageBox.Show("请输入姓名！");
                txtName.Focus();
                return;
            }
            if(strUserName.Length>30)
            {
                MessageBox.Show("姓名过长！");
                txtName.Focus();
                return;
            }
            if (strUserDep.Length == 0)
            {
                MessageBox.Show("请输入部门！");
                txtDep.Focus();
                return;
            }
            if (strUserDep.Length > 30)
            {
                MessageBox.Show("部门名字过长！");
                txtDep.Focus();
                return;
            }

            if (strUserCountry.Length == 0)
            {
                MessageBox.Show("请输入国籍！");
                txtCountry.Focus();
                return;
            }
            if (strUserCountry.Length > 30)
            {
                MessageBox.Show("国家名字过长！");
                txtCountry.Focus();
                return;
            }

            if (strUserPhone.Length == 0)
            {
                MessageBox.Show("请输入手机号！");
                txtPhone.Focus();
                return;
            }
            if (strUserPhone.Length >11)
            {
                MessageBox.Show("手机号非法");
                txtPhone.Focus();
                return;
            }        
                
            if (strGED == "")
            {
                MessageBox.Show("请输入性别！");
                return;
            }

            int Cou = 0;
            try
            {
                string[] returnparm = new string[2];
                string errinfo = "";
                string sysIxdex = "";
                string sysMessage = "";
                dao.RunProcedure("SP_TMP_USERMAINTAIN", new OracleParameter[9]  {
                new OracleParameter("v_state", status) { OracleType = OracleType.Int32, Size=12 },
                new OracleParameter("v_id", arr[0]) { OracleType = OracleType.VarChar, Size=20},
                new OracleParameter("v_name", strUserName) { OracleType = OracleType.VarChar, Size=20 },
                new OracleParameter("v_Dep", strUserDep) { OracleType = OracleType.VarChar, Size=20},
                new OracleParameter("v_Phone", strUserPhone) { OracleType = OracleType.VarChar, Size=20 },
                new OracleParameter("v_Country", strUserCountry) { OracleType = OracleType.VarChar, Size=20 },
                new OracleParameter("v_Ged", strGED) { OracleType = OracleType.VarChar, Size=20},
                new OracleParameter("o_rtnmsg", OracleType.VarChar,20) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar },
                new OracleParameter("o_index", OracleType.VarChar,20) { Direction = ParameterDirection.Output, OracleType = OracleType.VarChar }
            }, out returnparm, out errinfo);
                sysMessage = returnparm[0].Trim();
                sysIxdex = returnparm[1].Trim();                                    
                MessageBox.Show(sysMessage);
                Cou = int.Parse(sysIxdex);
            }
            catch (Exception ex)
            {
            log.ErrorFormat("错误：{0}", ex.Message);
            MessageBox.Show(ex.ToString());
            }
            if (Cou == 1)
            {
                log.InfoFormat("添加新员工{0}", strUserName);
            }
            if (Cou == 2)
            {
                log.InfoFormat("修改操作");
            }
                Close();
        }                 
    }
 }
 

